﻿using ChocolateVendo.Models;
using System.Collections.Generic;

namespace ChocolateVendo.BL.Interfaces
{
    public interface IChocolateVendoEngine
    {
        public OrderModel Buy(string selectedChocolate, OrderModel order);
        public OrderModel InsertCoin(OrderModel order, string insertedCoin);
        public OrderModel GetRefund(OrderModel order);
        public List<BaseChocolateModel> GetAllAvailableChocolates();
    }
}
