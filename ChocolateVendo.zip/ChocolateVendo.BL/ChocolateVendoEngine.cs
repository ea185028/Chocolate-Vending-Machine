﻿using ChocolateVendo.Models;
using ChocolateVendo.BL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChocolateVendo.BL
{
    public class ChocolateVendoEngine : IChocolateVendoEngine
    {
        public OrderModel Buy(string selectedChocolate, OrderModel order)
        {
            if (string.IsNullOrEmpty(selectedChocolate))
            {
                order.ErrorMessage = "Please select a chocolate to buy";
            }

            var chocolateSelections = GetAllAvailableChocolates();
            var first = chocolateSelections.First(x => x.Name == selectedChocolate);

            order.Change = order.TotalInsertedAmount - first.Price;
            order.TotalInsertedAmount = 0;
            order.InfoMessage = "Thank you for purchasing a/an " + first.Name + " chocolate bar.";

            if (order.Change > 0)
            {
                order.InfoMessage += " Please do not forget to take your change.";
            }

            return order;
        }

        public List<BaseChocolateModel> GetAllAvailableChocolates()
        {
            var baseChocolate = typeof(BaseChocolateModel);
            var chocolatesForSale = new List<BaseChocolateModel>();

            foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (var t in a.GetTypes())
                {
                    if (t.IsSubclassOf(baseChocolate))
                    {
                        var genericChocolate = (BaseChocolateModel)Activator.CreateInstance(t);
                        chocolatesForSale.Add(genericChocolate);
                    }
                }
            }

            return chocolatesForSale;
        }

        public OrderModel GetRefund(OrderModel order)
        {
            order.Change = order.TotalInsertedAmount;
            order.InfoMessage = "You have been refunded: $" + order.TotalInsertedAmount;
            order.TotalInsertedAmount = 0;

            return order;
        }

        public OrderModel InsertCoin(OrderModel order, string insertedCoin)
        {
            order.InfoMessage = string.Empty;
            order.ErrorMessage = string.Empty;
            order.Change = 0;

            switch (insertedCoin)
            {
                case "10c":
                    {
                        order.TotalInsertedAmount += decimal.Parse("0.10");
                        order.InfoMessage = "You have successfully added .10c";
                        break;
                    }
                case "20c":
                    {
                        order.TotalInsertedAmount += decimal.Parse("0.20");
                        order.InfoMessage = "You have successfully added .20c";
                        break;
                    }
                case "50c":
                    {
                        order.TotalInsertedAmount += decimal.Parse("0.50");
                        order.InfoMessage = "You have successfully added .50c";
                        break;
                    }
                case "1$":
                    {
                        order.TotalInsertedAmount += decimal.Parse("1.00");
                        order.InfoMessage = "You have successfully added 1$";
                        break;
                    }
                case "$1":
                    {
                        order.TotalInsertedAmount += decimal.Parse("1.00");
                        order.InfoMessage = "You have successfully added 1$";
                        break;
                    }
                case "2$":
                    {
                        order.TotalInsertedAmount += decimal.Parse("2.00");
                        order.InfoMessage = "You have successfully added 2$";
                        break;
                    }
                case "$2":
                    {
                        order.TotalInsertedAmount += decimal.Parse("2.00");
                        order.InfoMessage = "You have successfully added 2$";
                        break;
                    }
                default:
                    {
                        order.ErrorMessage = "You have entered an invalid coin";
                        break;
                    }
            }

            return order;
        }
    }
}
