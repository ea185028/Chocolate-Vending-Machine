﻿using ChocolateVendo.BL.Interfaces;
using ChocolateVendo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace ChocolateVendo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IChocolateVendoEngine _chocolateEngine;
        private static OrderModel Order { get; set; }

        public HomeController(ILogger<HomeController> logger, IChocolateVendoEngine chocolateEngine)
        {
            _logger = logger;
            _chocolateEngine = chocolateEngine;
        }

        public IActionResult Index()
        {
            Order = new OrderModel
            {
                AvailableSelections = _chocolateEngine.GetAllAvailableChocolates(),
                InfoMessage = string.Empty,
                ErrorMessage = string.Empty
            };

            return View(Order);
        }

        [HttpPost]
        public ActionResult InsertCoin(string insertedCoin)
        {
            Order = _chocolateEngine.InsertCoin(Order, insertedCoin);
            return View("Index", Order);
        }

        [HttpGet]
        public ActionResult GetRefund()
        {
            Order = _chocolateEngine.GetRefund(Order);
            return View("Index", Order);
        }

        [HttpPost]
        public ActionResult Buy(string selectedChocolate)
        {
            Order = _chocolateEngine.Buy(selectedChocolate, Order);
            return View("Index", Order);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
