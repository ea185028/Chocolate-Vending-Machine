using ChocolateVendo.BL;
using ChocolateVendo.BL.Interfaces;
using ChocolateVendo.Models;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChocolateVendo.Test
{
    [TestClass]
    public class ChocolateVendoTest
    {
        private readonly IChocolateVendoEngine _chocoEngine;

        public ChocolateVendoTest()
        {
            var services = new ServiceCollection();
            services.AddTransient<IChocolateVendoEngine, ChocolateVendoEngine>();

            var serviceProvider = services.BuildServiceProvider();
            
            _chocoEngine = serviceProvider.GetService<IChocolateVendoEngine>();
        }
        
        [TestMethod]
        public void Test_Buy()
        {
            var chocolatesForSale = _chocoEngine.GetAllAvailableChocolates();
            var selectedChocolate = chocolatesForSale[0].Name;

            var model = new OrderModel
            {
                TotalInsertedAmount = 5M
            };

            model = _chocoEngine.Buy(selectedChocolate, model);

            Assert.IsTrue(!string.IsNullOrEmpty(model.InfoMessage));
            Assert.IsTrue(string.IsNullOrEmpty(model.ErrorMessage));
            Assert.IsTrue(model.Change > 0);
            Assert.IsTrue(model.TotalInsertedAmount == 0);
        }

        [TestMethod]
        public void Test_InsertCoin()
        {
            var model = new OrderModel();
            model = _chocoEngine.InsertCoin(model, "10c");

            Assert.IsTrue(!string.IsNullOrEmpty(model.InfoMessage));
            Assert.IsTrue(string.IsNullOrEmpty(model.ErrorMessage));
            Assert.IsTrue(model.TotalInsertedAmount == .10M);
        }

        [TestMethod]
        public void Test_GetRefund()
        {
            var model = new OrderModel {
                TotalInsertedAmount = 5M
            };
            
            model = _chocoEngine.GetRefund(model);

            Assert.IsTrue(!string.IsNullOrEmpty(model.InfoMessage));
            Assert.IsTrue(string.IsNullOrEmpty(model.ErrorMessage));
            Assert.IsTrue(model.Change == 5M);
            Assert.IsTrue(model.TotalInsertedAmount == 0);
        }

        [TestMethod]
        public void Test_GetAllAvailableChocolates()
        {
            var chocolates = _chocoEngine.GetAllAvailableChocolates();
            Assert.IsTrue(chocolates.Count > 0);
        }
    }
}
