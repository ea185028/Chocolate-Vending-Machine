namespace ChocolateVendo.Models
{
    public abstract class BaseChocolateModel
    {
        public virtual string Name
        {
            get
            {
                return "Chocolate";
            }
            set
            {
                Name = value;
            }
        }

        public virtual decimal Price
        {
            get
            {
                return 0;
            }
            set
            {
                Price = value;
            }
        }
    }
}
