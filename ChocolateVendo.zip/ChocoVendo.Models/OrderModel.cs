using System.Collections.Generic;

namespace ChocolateVendo.Models
{
    public class OrderModel
    {
        public string SelectedChocolate
        {
            get; set;
        }

        public List<BaseChocolateModel> AvailableSelections { get; set; }

        public string InsertedCoin { get; set; }
        public decimal TotalInsertedAmount { get; set; }
        public decimal Change { get; set; }
        public string InfoMessage { get; set; }
        public string ErrorMessage { get; set; }
    }
}
