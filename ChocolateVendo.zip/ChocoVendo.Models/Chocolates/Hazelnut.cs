using System;

namespace ChocolateVendo.Models
{
    public class Hazelnut : BaseChocolateModel
    {
        public override string Name => "Hazel nut";
        public override decimal Price => 3.10M;
    }
}
