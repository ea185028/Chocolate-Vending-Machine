using System;

namespace ChocolateVendo.Models
{
    public class OrganicRaw : BaseChocolateModel
    {
        public override string Name => "Organic Raw";
        public override decimal Price => 2M;
    }
}
