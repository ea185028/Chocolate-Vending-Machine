using System;

namespace ChocolateVendo.Models
{
    public class Caramel : BaseChocolateModel
    {
        public override string Name => "Caramel";
        public override decimal Price => 2.5M;
    }
}
